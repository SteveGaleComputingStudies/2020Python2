import os

hostnames = [
    '192.168.223.2',
    '192.168.223.3',
    '192.168.223.4',
    '192.168.223.5',
]

for hostname in hostnames:
    response = os.system('ping -c 1 ' + hostname)   # note always returns 0 response in windows
    if response == 0:
        print( hostname + 'is up')
    else:
        print( hostname + 'is down')                # does not work in windows