import os

hosts = ["192.168.223.254"] # list of host addresses

for host in hosts:
    os.system('ping ' + host)


# https://www.ictshore.com/python/python-ping-tutorial/