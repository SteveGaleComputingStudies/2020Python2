import matplotlib.pyplot as plt


#plt.plot([xvalues],[yvalues],options='..')
plt.plot([1, 2, 3, 4], [1, 4, 9, 16]) 

plt.show()