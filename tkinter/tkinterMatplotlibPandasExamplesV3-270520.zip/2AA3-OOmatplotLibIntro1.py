import matplotlib.pyplot as plt


fig, ax = plt.subplots()  #  a figure containing an axes.
#plot of y = x^2
ax.plot([1, 2, 3, 4], [1, 4, 9, 16])  # Plot x and y data on the axes.
plt.show()